import React from 'react';
import Classes from './Spinner.Module.css'
const spinner=()=>(
<div className={Classes.Loader}>Loading...</div>
)

export default spinner